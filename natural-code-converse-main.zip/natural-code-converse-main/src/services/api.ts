
import axios from 'axios';
import { QueryResponse, FeedbackData } from '../types';

// In a real app, this would come from environment variables
const API_BASE_URL = 'http://localhost:8000';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

export const submitQuery = async (query: string): Promise<QueryResponse> => {
  try {
    // In a real app, this would be a real API call
    // For now, we'll simulate the response
    
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const sampleResponse: QueryResponse = {
      id: `query-${Date.now()}`,
      query,
      results: [
        {
          code: `function calculateSum(a, b) {\n  return a + b;\n}`,
          language: 'javascript',
          confidence: 0.95,
          path: 'src/utils/math.js',
          hierarchy: ['utils', 'math', 'calculateSum'],
        },
        {
          code: `def calculate_sum(a, b):\n    return a + b`,
          language: 'python',
          confidence: 0.82,
          path: 'src/utils/math.py',
          hierarchy: ['utils', 'math', 'calculate_sum'],
        }
      ]
    };
    
    return sampleResponse;
  } catch (error) {
    console.error('Error submitting query:', error);
    throw error;
  }
};

export const submitFeedback = async (feedbackData: FeedbackData): Promise<void> => {
  try {
    console.log('Feedback submitted:', feedbackData);
    // In a real app, this would be a real API call
    // await api.post('/feedback', feedbackData);
    
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 500));
  } catch (error) {
    console.error('Error submitting feedback:', error);
    throw error;
  }
};

export default api;
