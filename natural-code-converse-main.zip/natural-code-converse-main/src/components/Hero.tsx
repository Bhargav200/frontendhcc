
import { ArrowRight } from 'lucide-react';

const Hero = () => {
  return (
    <section className="pt-32 pb-20 md:pt-40 md:pb-28">
      <div className="container px-4 mx-auto">
        <div className="flex flex-col md:flex-row md:items-center md:gap-12">
          <div className="max-w-3xl md:w-1/2 mb-12 md:mb-0 text-center md:text-left">
            <div className="inline-block px-3 py-1 mb-6 text-xs font-medium text-primary bg-primary/10 rounded-full animate-fade-in">
              A new way to query code
            </div>
            <h1 className="mb-6 text-4xl font-bold tracking-tight md:text-5xl lg:text-6xl text-balance animate-slide-up">
              Query Your Codebase Using <span className="text-primary">Natural Language</span>
            </h1>
            <p className="max-w-2xl mx-auto md:mx-0 mb-10 text-lg text-foreground/70 md:text-xl text-balance animate-slide-up" style={{ animationDelay: '100ms' }}>
              Enhance your coding workflow with AI-driven search tailored to the needs of HCC (Hierarchical Condition Category) medical coders, helping you find accurate ICD-10 codes, risk-adjustment factors, and documentation with ease.
            </p>
            <div className="flex flex-col items-center md:items-start space-y-4 md:space-y-0 md:space-x-4 md:flex-row md:justify-start animate-slide-up" style={{ animationDelay: '200ms' }}>
              <a
                href="#try"
                className="flex items-center justify-center w-full px-6 py-3 font-medium text-white transition-all bg-primary rounded-lg md:w-auto hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-primary/50"
              >
                Try It Now
                <ArrowRight className="w-4 h-4 ml-2" />
              </a>
              <a
                href="#documentation"
                className="flex items-center justify-center w-full px-6 py-3 font-medium transition-all border rounded-lg md:w-auto text-foreground/90 border-border hover:bg-secondary focus:outline-none focus:ring-2 focus:ring-primary/50"
              >
                Documentation
              </a>
            </div>
          </div>
          
          <div className="md:w-1/2 flex justify-center animate-fade-in" style={{ animationDelay: '300ms' }}>
            <div className="relative w-full max-w-md overflow-hidden rounded-lg shadow-xl glass">
              <img 
                src="https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExYjJheWg1enRtanBsM3QyOXQydG8zc3ozemF6dmVkejdxZXdpbjZkbSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/3oKIPEqDGUULpEU0aQ/giphy.gif" 
                alt="Medical coding and healthcare data visualization" 
                className="w-full object-cover"
              />
              <div className="absolute bottom-0 left-0 right-0 p-4 bg-black/40 backdrop-blur-sm">
                <p className="text-white text-sm font-medium">
                  AI-powered medical code search and analysis
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
