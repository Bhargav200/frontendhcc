
import { useState, useEffect } from 'react';
import { Code, Menu, X } from 'lucide-react';

const Header = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 10;
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [scrolled]);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-background/80 backdrop-blur-md shadow-subtle' : 'bg-transparent'
      }`}
    >
      <div className="container px-4 mx-auto">
        <div className="flex items-center justify-between h-16 md:h-20">
          <div className="flex items-center">
            <a href="/" className="flex items-center">
              <Code className="w-8 h-8 text-primary" />
              <span className="ml-2 text-xl font-medium">CodeQuery</span>
            </a>
          </div>

          <nav className="hidden md:block">
            <ul className="flex space-x-8">
              <li>
                <a
                  href="#features"
                  className="text-sm text-foreground/80 hover:text-foreground transition-colors"
                >
                  Features
                </a>
              </li>
              <li>
                <a
                  href="#documentation"
                  className="text-sm text-foreground/80 hover:text-foreground transition-colors"
                >
                  Documentation
                </a>
              </li>
              <li>
                <a
                  href="#github"
                  className="text-sm text-foreground/80 hover:text-foreground transition-colors"
                >
                  GitHub
                </a>
              </li>
            </ul>
          </nav>

          <div className="hidden md:block">
            <a
              href="#try"
              className="px-5 py-2 text-sm font-medium text-white transition-all bg-primary rounded-lg hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-primary/50"
            >
              Try It Now
            </a>
          </div>

          <button
            className="p-2 text-foreground md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="absolute w-full bg-background/95 backdrop-blur-lg shadow-subtle md:hidden animate-slide-down">
          <div className="px-4 py-4">
            <ul className="flex flex-col space-y-4">
              <li>
                <a
                  href="#features"
                  className="block text-sm text-foreground/80 hover:text-foreground"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Features
                </a>
              </li>
              <li>
                <a
                  href="#documentation"
                  className="block text-sm text-foreground/80 hover:text-foreground"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Documentation
                </a>
              </li>
              <li>
                <a
                  href="#github"
                  className="block text-sm text-foreground/80 hover:text-foreground"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  GitHub
                </a>
              </li>
              <li>
                <a
                  href="#try"
                  className="inline-block px-5 py-2 text-sm font-medium text-white transition-all bg-primary rounded-lg hover:bg-primary/90"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Try It Now
                </a>
              </li>
            </ul>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
