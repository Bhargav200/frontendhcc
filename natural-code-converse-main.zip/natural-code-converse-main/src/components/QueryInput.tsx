
import { useState, useRef, useEffect } from 'react';
import { Search, Loader2 } from 'lucide-react';

interface QueryInputProps {
  onSubmit: (query: string) => void;
  isLoading: boolean;
}

const QueryInput = ({ onSubmit, isLoading }: QueryInputProps) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Auto-resize textarea
  useEffect(() => {
    const textarea = inputRef.current;
    if (textarea) {
      textarea.style.height = 'auto';
      textarea.style.height = `${Math.min(textarea.scrollHeight, 200)}px`;
    }
  }, [query]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim() && !isLoading) {
      onSubmit(query.trim());
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  return (
    <div className="w-full max-w-3xl mx-auto">
      <form onSubmit={handleSubmit} className="relative">
        <div className="relative transition-all duration-300 bg-white border rounded-lg shadow-subtle focus-within:shadow-md focus-within:border-primary/50 focus-within:ring-2 focus-within:ring-primary/20">
          <textarea
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask a question about your codebase... e.g., 'Find functions that calculate sums'"
            className="w-full p-4 pr-16 text-base resize-none bg-transparent outline-none min-h-[56px] max-h-[200px] placeholder:text-foreground/40"
            disabled={isLoading}
            rows={1}
            aria-label="Query input"
          />
          <button
            type="submit"
            className={`absolute right-3 bottom-3 p-2 rounded-md transition-all ${
              query.trim() && !isLoading
                ? 'bg-primary text-white hover:bg-primary/90'
                : 'bg-secondary text-foreground/40'
            }`}
            disabled={!query.trim() || isLoading}
            aria-label="Submit query"
          >
            {isLoading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Search className="w-5 h-5" />
            )}
          </button>
        </div>
        <p className="mt-2 text-xs text-foreground/50">
          Press Enter to submit. Use Shift+Enter for a new line.
        </p>
      </form>
    </div>
  );
};

export default QueryInput;
