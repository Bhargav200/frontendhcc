
import { useState } from 'react';
import { ThumbsUp, ThumbsDown } from 'lucide-react';

interface FeedbackButtonProps {
  onFeedback: (type: 'positive' | 'negative') => void;
}

const FeedbackButton = ({ onFeedback }: FeedbackButtonProps) => {
  const [selectedFeedback, setSelectedFeedback] = useState<'positive' | 'negative' | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const handleFeedback = (type: 'positive' | 'negative') => {
    if (submitted) return;
    
    setSelectedFeedback(type);
    onFeedback(type);
    setSubmitted(true);
    
    // Reset after some time for a new feedback opportunity
    setTimeout(() => {
      setSubmitted(false);
      setSelectedFeedback(null);
    }, 5000);
  };

  if (submitted) {
    return (
      <div className="flex items-center px-3 py-1 text-xs bg-green-100 border border-green-200 rounded-full text-green-700">
        <ThumbsUp className="w-3 h-3 mr-1" />
        Thank you for the feedback!
      </div>
    );
  }

  return (
    <div 
      className="relative flex bg-secondary/80 rounded-full p-1 border border-border transition-all"
      onMouseEnter={() => setIsHovered(true)} 
      onMouseLeave={() => setIsHovered(false)}
    >
      <button
        className={`p-1 transition-all rounded-full ${
          selectedFeedback === 'positive'
            ? 'bg-green-500 text-white'
            : 'hover:bg-secondary'
        }`}
        onClick={() => handleFeedback('positive')}
        aria-label="Helpful"
      >
        <ThumbsUp className="w-4 h-4" />
      </button>
      <button
        className={`p-1 transition-all rounded-full ${
          selectedFeedback === 'negative'
            ? 'bg-red-500 text-white'
            : 'hover:bg-secondary'
        }`}
        onClick={() => handleFeedback('negative')}
        aria-label="Not helpful"
      >
        <ThumbsDown className="w-4 h-4" />
      </button>
      {isHovered && (
        <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 whitespace-nowrap px-2 py-1 text-xs bg-foreground text-background rounded shadow-md animate-fade-in">
          Was this helpful?
        </div>
      )}
    </div>
  );
};

export default FeedbackButton;
