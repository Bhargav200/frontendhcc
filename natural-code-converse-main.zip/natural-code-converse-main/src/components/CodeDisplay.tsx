
import { useState } from 'react';
import { CodeResult } from '../types';
import { ChevronDown, ChevronRight, File, Folder } from 'lucide-react';
import FeedbackButton from './FeedbackButton';

interface CodeDisplayProps {
  results: CodeResult[];
  onFeedback: (type: 'positive' | 'negative') => void;
}

const CodeDisplay = ({ results, onFeedback }: CodeDisplayProps) => {
  const [expandedPaths, setExpandedPaths] = useState<string[]>([]);

  const togglePath = (path: string) => {
    setExpandedPaths((prev) =>
      prev.includes(path) ? prev.filter((p) => p !== path) : [...prev, path]
    );
  };

  if (!results.length) {
    return null;
  }

  const renderHierarchy = (result: CodeResult, index: number) => {
    if (!result.hierarchy) return null;

    // Build all possible paths from the hierarchy
    const paths: string[] = [];
    for (let i = 0; i < result.hierarchy.length; i++) {
      paths.push(result.hierarchy.slice(0, i + 1).join('/'));
    }

    // Render hierarchy
    const renderNode = (level: number, path: string, isLast: boolean) => {
      const isFile = level === result.hierarchy!.length - 1;
      const isExpanded = expandedPaths.includes(path);
      const nodeName = result.hierarchy![level];
      const shouldShowChildren = level < result.hierarchy!.length - 1 && isExpanded;

      return (
        <div key={`${index}-${path}`} className="ml-4">
          <div
            className={`flex items-center py-1 text-sm ${
              isFile ? 'text-foreground' : 'text-foreground/80 hover:text-foreground'
            } cursor-pointer`}
            onClick={() => !isFile && togglePath(path)}
          >
            {!isFile ? (
              <>
                {isExpanded ? (
                  <ChevronDown className="w-4 h-4 mr-1 text-foreground/60" />
                ) : (
                  <ChevronRight className="w-4 h-4 mr-1 text-foreground/60" />
                )}
                <Folder className="w-4 h-4 mr-2 text-primary/80" />
              </>
            ) : (
              <>
                <div className="w-4 h-4 mr-1" />
                <File className="w-4 h-4 mr-2 text-foreground/60" />
              </>
            )}
            <span>{nodeName}</span>
          </div>
          {shouldShowChildren && (
            <div>
              {renderNode(level + 1, `${path}/${result.hierarchy![level + 1]}`, level + 1 === result.hierarchy!.length - 1)}
            </div>
          )}
        </div>
      );
    };

    return (
      <div className="mb-2 border rounded-lg bg-secondary/50">
        <div className="p-3">
          <div className="text-xs text-foreground/60 mb-1">File path:</div>
          {renderNode(0, result.hierarchy[0], result.hierarchy.length === 1)}
        </div>
      </div>
    );
  };

  return (
    <div className="w-full max-w-3xl mx-auto">
      <div className="animate-scale-in">
        {results.map((result, index) => (
          <div
            key={index}
            className="mb-6 overflow-hidden border rounded-lg shadow-subtle"
          >
            <div className="flex justify-between items-center p-3 border-b bg-secondary/30">
              <div className="flex flex-col">
                <div className="text-sm font-medium">{result.language}</div>
                <div className="text-xs text-foreground/60">
                  Confidence: {Math.round(result.confidence * 100)}%
                </div>
              </div>
              {index === 0 && (
                <div className="flex space-x-2">
                  <FeedbackButton onFeedback={onFeedback} />
                </div>
              )}
            </div>
            
            {renderHierarchy(result, index)}
            
            <div className="p-4 overflow-x-auto bg-white dark:bg-green-950/95">
              <pre className="text-sm font-mono">{result.code}</pre>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CodeDisplay;
