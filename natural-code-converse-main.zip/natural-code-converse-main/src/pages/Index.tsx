
import { useState, useEffect, useRef } from 'react';
import Header from '../components/Header';
import Hero from '../components/Hero';
import QueryInput from '../components/QueryInput';
import CodeDisplay from '../components/CodeDisplay';
import { submitQuery, submitFeedback } from '../services/api';
import { QueryResponse, FeedbackType } from '../types';
import { Loader2, Code, Zap, MessageSquare } from 'lucide-react';

const Index = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [queryResponse, setQueryResponse] = useState<QueryResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const resultsRef = useRef<HTMLDivElement>(null);

  const handleSubmit = async (query: string) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await submitQuery(query);
      setQueryResponse(response);
      
      // Scroll to results after a short delay to allow for rendering
      setTimeout(() => {
        resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);
    } catch (err) {
      setError('An error occurred. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFeedback = (type: FeedbackType) => {
    if (!queryResponse || !type) return;
    
    submitFeedback({
      queryId: queryResponse.id,
      feedback: type,
    }).catch(console.error);
  };

  return (
    <div className="min-h-screen">
      <Header />
      
      <main>
        <Hero />
        
        <section id="try" className="py-16 bg-secondary/30">
          <div className="container px-4 mx-auto">
            <div className="max-w-4xl mx-auto text-center mb-12">
              <h2 className="mb-4 text-3xl font-bold md:text-4xl">Try It Now</h2>
              <p className="max-w-2xl mx-auto text-foreground/70">
                Ask a question about code in natural language and see how our system responds.
              </p>
            </div>
            
            <QueryInput onSubmit={handleSubmit} isLoading={isLoading} />
            
            <div ref={resultsRef} className="mt-8">
              {isLoading ? (
                <div className="flex flex-col items-center justify-center py-16">
                  <Loader2 className="w-10 h-10 text-primary animate-spin" />
                  <p className="mt-4 text-foreground/70">Processing your query...</p>
                </div>
              ) : error ? (
                <div className="p-4 mt-4 text-center text-red-700 bg-red-100 border border-red-200 rounded-lg">
                  {error}
                </div>
              ) : queryResponse ? (
                <CodeDisplay 
                  results={queryResponse.results} 
                  onFeedback={handleFeedback} 
                />
              ) : null}
            </div>
          </div>
        </section>
        
        <section id="features" className="py-20">
          <div className="container px-4 mx-auto">
            <div className="max-w-4xl mx-auto text-center mb-12">
              <h2 className="mb-4 text-3xl font-bold md:text-4xl">Key Features</h2>
              <p className="max-w-2xl mx-auto text-foreground/70">
                Our system provides powerful capabilities to help you interact with code using natural language.
              </p>
            </div>
            
            <div className="grid gap-8 md:grid-cols-3">
              <div className="p-6 transition-all border rounded-lg hover:shadow-subtle hover:border-primary/20">
                <div className="p-3 mb-4 text-white bg-primary rounded-full w-fit">
                  <MessageSquare className="w-6 h-6" />
                </div>
                <h3 className="mb-2 text-xl font-medium">Natural Language Queries</h3>
                <p className="text-foreground/70">
                  Ask questions in plain English to quickly find the code you're looking for.
                </p>
              </div>
              
              <div className="p-6 transition-all border rounded-lg hover:shadow-subtle hover:border-primary/20">
                <div className="p-3 mb-4 text-white bg-primary rounded-full w-fit">
                  <Code className="w-6 h-6" />
                </div>
                <h3 className="mb-2 text-xl font-medium">Code Hierarchy</h3>
                <p className="text-foreground/70">
                  View code in its structural context with folder and file organization.
                </p>
              </div>
              
              <div className="p-6 transition-all border rounded-lg hover:shadow-subtle hover:border-primary/20">
                <div className="p-3 mb-4 text-white bg-primary rounded-full w-fit">
                  <Zap className="w-6 h-6" />
                </div>
                <h3 className="mb-2 text-xl font-medium">Feedback Loop</h3>
                <p className="text-foreground/70">
                  Provide feedback on results to help improve the system over time.
                </p>
              </div>
            </div>
          </div>
        </section>
        
        <section id="documentation" className="py-20 bg-secondary/30">
          <div className="container px-4 mx-auto">
            <div className="max-w-4xl mx-auto text-center mb-12">
              <h2 className="mb-4 text-3xl font-bold md:text-4xl">Documentation</h2>
              <p className="max-w-2xl mx-auto text-foreground/70">
                Learn how to use and integrate our code query system into your workflow.
              </p>
            </div>
            
            <div className="max-w-3xl mx-auto p-6 bg-white border rounded-lg shadow-subtle">
              <h3 className="mb-4 text-xl font-medium">Getting Started</h3>
              <p className="mb-4 text-foreground/70">
                This is a demonstration of the user interface. In a real application, you would connect
                to a backend system that processes your queries and returns relevant code snippets.
              </p>
              <div className="p-4 mb-4 border rounded-lg bg-secondary/30">
                <pre className="text-sm font-mono overflow-x-auto">
{`# Install dependencies
npm install

# Start the application
npm run dev

# In another terminal, start the backend
python backend/main.py`}
                </pre>
              </div>
              <p className="text-foreground/70">
                For more information, please refer to the project's GitHub repository.
              </p>
            </div>
          </div>
        </section>
      </main>
      
      <footer className="py-12 border-t">
        <div className="container px-4 mx-auto">
          <div className="flex flex-col items-center justify-between md:flex-row">
            <div className="flex items-center mb-4 md:mb-0">
              <Code className="w-6 h-6 text-primary" />
              <span className="ml-2 text-lg font-medium">CodeQuery</span>
            </div>
            <div className="text-sm text-foreground/60">
              &copy; {new Date().getFullYear()} CodeQuery. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
