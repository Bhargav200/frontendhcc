
export interface CodeResult {
  code: string;
  language: string;
  confidence: number;
  path?: string;
  hierarchy?: string[];
}

export interface QueryResponse {
  results: CodeResult[];
  query: string;
  id: string;
}

export type FeedbackType = 'positive' | 'negative' | null;

export interface FeedbackData {
  queryId: string;
  feedback: FeedbackType;
  comments?: string;
}
